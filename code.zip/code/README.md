## Hi, this is the code for our final project

## Files
**./fine_tuning** is the .ipynb files for fine-tuning we did in Section 2 in this project

**./utils** are tools needed for fine-tuning.

For more detailed including the implementation of **ViT/SPOTER/I3D**, please go https://github.com/hd322/CS444_Final_Project! Thank you!

## How to Run:
```
# collect your own sign data
python collect.py 

# train the model on your own data
python train_v2.py

# Run the translation system in UI
python server.py

# If you want to run locally with Webcam
python demo_v4.py
```

## Test
Since the model checkpoint is small, we already uploaded it in ./checkpoint

You can run
```
python server.py
```
Directly on our pre_trained model

## Demo
> 🎥 **Video** (Click the image to watch):
>
> [![Watch the video](./demo.png)](https://youtu.be/GcPIRCYa2u8)
